export interface User {
  email: string;
  name: string;
}

export interface Expense {
  category: ExpenseCategory;
  amount: number;
}

export type ExpenseCategory = 'Food' | 'Hostel/Rent' | 'Travel' | 'Education' | 'Miscellaneous';

export const EXPENSE_CATEGORIES: ExpenseCategory[] = ['Food', 'Hostel/Rent', 'Travel', 'Education', 'Miscellaneous'];

export interface BudgetData {
  monthlyIncome: number;
  expenses: Expense[];
}

export interface LoanData {
  principal: number;
  annualRate: number;
  courseDuration: number;
  loanTenure: number;
  moratoriumPeriod: number;
}

export interface EMIResult {
  monthlyEMI: number;
  totalPayable: number;
  totalInterest: number;
}

export interface MonthBreakdown {
  month: number;
  emi: number;
  interest: number;
  principal: number;
  balance: number;
}

export interface EarlyRepaymentInput {
  extraMonthly: number;
  oneTimePrepayment: number;
}

export interface RepaymentComparison {
  normal: {
    totalMonths: number;
    totalInterest: number;
    totalPayable: number;
  };
  early: {
    totalMonths: number;
    totalInterest: number;
    totalPayable: number;
  };
  interestSaved: number;
  monthsSaved: number;
}

export interface AppState {
  user: User | null;
  budget: BudgetData;
  loan: LoanData;
  earlyRepayment: EarlyRepaymentInput;
}
